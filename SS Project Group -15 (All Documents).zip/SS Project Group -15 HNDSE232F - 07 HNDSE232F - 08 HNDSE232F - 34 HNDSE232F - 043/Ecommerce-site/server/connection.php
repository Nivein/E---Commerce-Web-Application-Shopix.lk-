<?php
$conn=mysqli_connect("localhost","ashwaq","ashwaq2001","php_project")
      or die("Couldn't connect to database");
?> 